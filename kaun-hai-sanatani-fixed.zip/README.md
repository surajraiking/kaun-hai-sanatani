# Kaun Hai Sanatani?

Standalone Expo Android app. Offline quiz works without a server. Optional online Gemini features use `EXPO_PUBLIC_API_URL`; the Gemini API key must stay on a server and must never be bundled into the app.

## Build
- `npm install`
- `npm run typecheck`
- `npm run build:apk`
- `npm run build:aab`

For GitHub Actions, add an Expo/EAS `EXPO_TOKEN` repository secret and run the Android workflow.
